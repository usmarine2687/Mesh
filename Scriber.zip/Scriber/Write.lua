Write = { _version = '2.0' }

Write.usecolors = true
Write.usetimestampconsole = false
Write.usetimestamplog = true
Write.loglevel = 'info'
Write.prefix = ''
Write.useoutfile = false
Write.outfile = nil

Write.loglevels = {
    ['trace']  = { level = 1, color = '\27[36m',  mqcolor = '\at', abbreviation = 'TRACE', },
    ['debug']  = { level = 2, color = '\27[95m',  mqcolor = '\am', abbreviation = 'DEBUG', },
    ['info']   = { level = 3, color = '\27[92m',  mqcolor = '\ag', abbreviation = 'INFO' , },
    ['warn']   = { level = 4, color = '\27[93m',  mqcolor = '\ay', abbreviation = 'WARN' , },
    ['error']  = { level = 5, color = '\27[31m',  mqcolor = '\ao', abbreviation = 'ERROR', },
    ['fatal']  = { level = 6, color = '\27[91m',  mqcolor = '\ar', abbreviation = 'FATAL', },
    ['help']   = { level = 7, color = '\27[97m',  mqcolor = '\aw', abbreviation = 'HELP' , },
}

Write.callstringlevel = Write.loglevels['debug'].level

local function Terminate()
    if package.loaded['mq'] then
        local mq = package.loaded['mq']

        mq.exit()
    end

    os.exit()
end

local function GetPath(filePath)
    if (not filePath or filePath == '') then
        return nil
    end

    return filePath:match("(.*[/\\])")
end

local function CheckLogFile()
    if (not Write.outfile or Write.outfile == '') then
        if (package.loaded['mq']) then
            local mq = package.loaded['mq']
    
            Write.outfile = string.format("%s\\Logs\\%s_%s.log", mq.TLO.MacroQuest.Path(), mq.TLO.EverQuest.Server(), mq.TLO.Me.CleanName())
        else
            Write.outfile = 'output.log'
        end
    else
        local path = GetPath(Write.outfile)

        if (not path and package.loaded['mq']) then
            local mq = package.loaded['mq']

            Write.outfile = string.format("%s\\Logs\\%s", mq.TLO.MacroQuest.Path(), Write.outfile)
        end
    end
end

local WriteLog = function(data)
    local file = io.open(Write.outfile, "a")

    file:write(data, "\n")
    file:close()
end

local function GetColorStart(paramLogLevel)
    if Write.usecolors then
        if package.loaded['mq'] then return Write.loglevels[paramLogLevel].mqcolor end
        return Write.loglevels[paramLogLevel].color
    end
    return ''
end

local function GetColorEnd()
    if Write.usecolors then
        if package.loaded['mq'] then
            return '\ax'
        end
        return '\27[0m'
    end
    return ''
end

local function GetCallerString()
    if Write.loglevels[Write.loglevel:lower()].level > Write.callstringlevel then
        return ''
    end

    local callString = 'unknown'
    local callerInfo = debug.getinfo(4,'Sl')
    if callerInfo and callerInfo.short_src ~= nil and callerInfo.short_src ~= '=[C]' then
        callString = string.format('%s::%s', callerInfo.short_src:match("[^\\^/]*.lua$"), callerInfo.currentline)
    end

    return string.format('(%s) ', callString)
end

local function TablePrint (data, indent)
    if not indent then indent = 0 end

    local output = string.rep(" ", indent) .. "{\r\n"
    indent = indent + 2
    
    for k, v in pairs(data) do
        output = output .. string.rep(" ", indent)
        
        if (type(k) == "number") then
            output = output .. "[" .. k .. "] = "
        elseif (type(k) == "string") then
            output = output  .. k ..  "= "   
        end
        
        if (type(v) == "number") then
            output = output .. v .. ",\r\n"
        elseif (type(v) == "string") then
            output = output .. "\"" .. v .. "\",\r\n"
        elseif (type(v) == "table") then
            output = output .. TablePrint(v, indent + 2) .. ",\r\n"
        else
            output = output .. "\"" .. tostring(v) .. "\",\r\n"
        end
    end
    
    output = output .. string.rep(" ", indent-2) .. "}"
    
    return output
end

local function NormalizeValue(v)
    local output

    if (v == nil) then
        output = 'nil'
    elseif (v == NULL) then
        output = 'NULL'
    elseif (type(v) == "number" or type(v) == "string") then
        output = v
    elseif (type(v) == "table") then
        output = TablePrint(v)
    else
        output = tostring(v)
    end

    return output
end

local function NormalizeArgs(...)
    local normalizedArgs = {}

    for i = 1, select('#', ...) do
        table.insert(normalizedArgs, NormalizeValue((select(i, ...))))
    end

    return unpack(normalizedArgs)
end

local function GetTimestamp()
    local _,milliseconds = math.modf(os.clock())

    if (milliseconds == 0) then
        milliseconds = '000'
    else
        milliseconds = tostring(milliseconds):sub(3,5)
    end
  
    local ts = os.date('%Y-%m-%d %X.')

    return ts..milliseconds
end

local function Output(logLevel, message, ...)
    local output

    if Write.loglevels[Write.loglevel:lower()].level <= Write.loglevels[logLevel].level then
        if (type(message) == "number") then
            output = message
        elseif (type(message) == "string") then
            output = string.format(message, NormalizeArgs(...))
        elseif (type(message) == "table") then
            output = TablePrint(message)
        else
            output = tostring(message)
        end

        local header = Write.prefix

        if (type(Write.prefix) == 'function') then
            header = Write.prefix()
        end

        local caller = GetCallerString()
        local timestamp = string.format('<%s> ', GetTimestamp())

        print(string.format('%s%s%s%s[%s]%s :: %s', Write.usetimestampconsole and timestamp or '', header, caller, GetColorStart(logLevel), Write.loglevels[logLevel].abbreviation, GetColorEnd(), output))
        
        if (Write.useoutfile) then
            CheckLogFile()

            local log = string.format('%s%s%s[%s] :: %s', Write.usetimestamplog and timestamp or '', header, caller, Write.loglevels[logLevel].abbreviation, output)
            
            WriteLog(log)
        end
    end
end

function Write.Debug(message, ...)
    Output('debug', message, ...)
end

function Write.Info(message, ...)
    Output('info', message, ...)
end

function Write.Warn(message, ...)
    Output('warn', message, ...)
end

function Write.Error(message, ...)
    Output('error', message, ...)
end

function Write.Fatal(message, ...)
    Output('fatal', message, ...)
    Terminate()
end

return Write
