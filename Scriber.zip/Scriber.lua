--  scriber.lua - Kuhle 2022-01-28
--
--  Buys all available spells and tomes for specified level range (default is level 1 to current level)
--  It will not buy lower rank spells than you already have. If you have a Rk. II spell it will not buy a Rk. I of the same name, but would buy a Rk. III if available.
--  When finished buying or if no windows are open, it scribes every available spell/tome found in inventory (regardless of level range given)
--
--  It will loop and keep buying/scribing until all possible spells are processed or runs out of inventory space.
--
--  usage:
--     /lua run Scriber [minLevel [maxLevel]]
--
--  parameters:
--     minLevel - int, optional, the minimum level of spells to consider on the merchant (default is 1)
--     maxLevel - int, optional, the maximum level of spells to consider on the merchant (default is current level)
--
--  examples:
--     /lua run scriber
--     ^^ This will buy all spells/tomes from level 1 to your current level from the current merchant
--
--     /lua run scriber 30
--     ^^ This will buy all spells/tomes from level 30 to your current level from the current merchant
--
--     /lua run Scriber 10 20
--     ^^ This will buy all spells/tomes from levels 10 to 20 from the current merchant
--
--  credits:
--     The original scribe LUA written by Rouneq
--     The original scribe macro written by Sym with updates from Chatwiththisname and Sic


local mq = require('mq')
local Write = require('Scriber.Write')
local Vendlist = require('Scriber.Merchants')

Write.prefix = 'Scribe'
Write.loglevel = 'info'

local ClassSN = mq.TLO.Me.Class.ShortName()
local MyClass = mq.TLO.Me.Class.Name()
local MyLevel = mq.TLO.Me.Level()
local MyDeity = mq.TLO.Me.Deity()
local TopInvSlot = 22 + mq.TLO.Me.NumBagSlots()
local MinLevel = 1
local MaxLevel = mq.TLO.Me.Level()
local DoLoop = true
local Scribing = false



-- --------------------------------------------------------------------------------------------
-- SUB: Event_NotGold
-- --------------------------------------------------------------------------------------------
local function Event_NotGold()
	Scribing = false
	Write.Debug('Gold access needed')
end

-- --------------------------------------------------------------------------------------------
-- SUB: Event_FinishedScribing
-- --------------------------------------------------------------------------------------------
local function Event_FinishedScribing(_, spell)
	Scribing = false
	Write.Debug('finished scribing/learning: %s', spell)
end

mq.event('NotGold', "#*#you do not have at least a gold membership#*#", Event_NotGold)
mq.event('FinishedScribing', "#*#You have finished scribing #1#", Event_FinishedScribing)
mq.event('FinishedLearning', "#*#You have learned #1#!#*#", Event_FinishedScribing)

local function IsUsableByClass(item)
	local isUsable = false

	for i = 1, item.Classes() do
		if (item.Class(i)() == MyClass) then
			isUsable = true

			break
		end
	end

	return isUsable
end

local function IsUsableByDiety(item)
	local isUsable = item.Deities() == 0

	for i = 1, item.Deities() do
		if (item.Deity(i)() == MyDeity) then
			isUsable = true

			break
		end
	end

	return isUsable
end

local function IsScribed(spellName, spellId)
	local bookId = mq.TLO.Me.Book(spellName)()

	if (not bookId) then
		bookId = mq.TLO.Me.CombatAbility(spellName)()
	end

	if (not bookId) then
		return false
	end
	
	if (bookId and not spellId) then
		return true
	end

	return mq.TLO.Me.Book(bookId).ID() == spellId or mq.TLO.Me.CombatAbility(bookId).ID() == spellId
end

local function UsableInvetoryCount()
	local count = mq.TLO.Me.FreeInventory()

	-- See if there's an empty top inventory slot
	for pack = 23, TopInvSlot do
		local item = mq.TLO.Me.Inventory(pack)

		if (item.ID() and item.Container() > 0 and
			(item.Type() == "Quiver" or item.Type() == "Tradeskill Bag" or item.Type() == "Collectible Bag")) then
			count = count - item.Container() + item.Items()
		end
	end

	return count
end

-- --------------------------------------------------------------------------------------------
-- SUB: BuySpells
-- --------------------------------------------------------------------------------------------
local function BuySpells()
	if (not mq.TLO.Merchant.Open() or mq.TLO.Merchant.Items() == 0) then
		return
	end

	mq.delay(2000)
	
	local index = 1
	local buyCount = 0

	while (index <= mq.TLO.Merchant.Items()) do
		if (UsableInvetoryCount() < 1 or not mq.TLO.Merchant.Open()) then
			break
		end

		local merchantItem = mq.TLO.Merchant.Item(index)
		local spellName = merchantItem.Spell.Name()
		local spellId = merchantItem.Spell.ID()
		local type = merchantItem.Type()
		local spellLevel = merchantItem.Spell.Level()
		local buyPrice = merchantItem.BuyPrice()
		Write.Debug('index: %s', index)
		Write.Debug('spellName: %s', spellName)

		if (spellName) then
			spellName = spellName:gsub(' Rk. II', '')
			spellName = spellName:gsub(' Rk. III', '')
		end

		-- Write.Debug('type: %s', type)
		-- if ((type == 'Scroll' or type == 'Tome')) then
		-- 	Write.Debug('type: %d', type)
		-- 	Write.Debug('IsScribed: %s', IsScribed(spellName, spellId))
		-- end
		-- Write.Debug('buyPrice: %d', buyPrice)
		-- Write.Debug('mq.TLO.Me.Platinum(): %f', mq.TLO.Me.Platinum())
		-- Write.Debug('(buyPrice / 1000) < mq.TLO.Me.Platinum(): %s', (buyPrice / 1000) < mq.TLO.Me.Platinum())
		-- Write.Debug('mq.TLO.Me.Book(spellName)(): %s', mq.TLO.Me.Book(spellName)())
		-- Write.Debug('mq.TLO.Me.Book(spellName).ID(): %s', mq.TLO.Me.Book(spellName).ID)
		-- Write.Debug('not mq.TLO.Me.Book(spellName).ID(): %s', not mq.TLO.Me.Book(spellName).ID)
		-- Write.Debug('mq.TLO.Me.CombatAbility(spellName).ID(): %s', mq.TLO.Me.CombatAbility(spellName).ID)
		-- Write.Debug('not mq.TLO.Me.CombatAbility(spellName).ID(): %s', not mq.TLO.Me.CombatAbility(spellName).ID)
		-- Write.Debug('mq.TLO.FindItemCount(spellName)(): %d', mq.TLO.FindItemCount(spellName)())
		-- Write.Debug('mq.TLO.FindItemCount(spellName)() == 0: %s', mq.TLO.FindItemCount(spellName)() == 0)
		if ((type == 'Scroll' or type == 'Tome') and 
			(spellLevel >= MinLevel and spellLevel <= MaxLevel) and 
            (buyPrice / 1000) < mq.TLO.Me.Platinum() and 
            (not IsScribed(spellName, spellId)) and 
            mq.TLO.FindItemCount(spellName)() == 0) then
			if (not IsUsableByClass(merchantItem)) then
				Write.Info('Unable to use %s because of class restrictions', spellName)

				goto continue
			end

			if (IsScribed(spellName..' Rk. II') or mq.TLO.FindItemCount(spellName..' Rk. II')() > 0 or
                IsScribed(spellName..' Rk. III') or mq.TLO.FindItemCount(spellName..' Rk. III')() > 0) then
				Write.Info(':: Skipping lower rank of '..spellName)

			    goto continue
			end

			if (not IsUsableByDiety(merchantItem)) then
				Write.Info('Unable to use '..spellName..' because of deity restrictions')
			    
				goto continue
			end

			mq.TLO.Merchant.SelectItem(merchantItem.Name())
			mq.TLO.Merchant.Buy(1)

			mq.delay(1000)
			mq.doevents()

			buyCount = buyCount + 1
		end

::continue::

		index = index + 1

		if (index > mq.TLO.Merchant.Items()) then
			DoLoop = false
		end
	end

	if (buyCount == 0) then
		DoLoop = false
	end
end

local function GetItem(pack, slot)
	Write.Debug('GetItem pack: %s', tostring(pack))
	Write.Debug('GetItem slot: %s', tostring(slot))
	local item = nil

    if (pack) then
        item = mq.TLO.Me.Inventory(pack)
		Write.Debug('item (pack): %s', tostring(item))
    end

    if (slot and slot > -1) then
        item = item.Item(slot + 1)
		Write.Debug('item (pack/slot): %s', tostring(item))
    end

	return item
end

local function FindFreeInventory()
	local location = { pack = nil, slot = nil }

	-- See if there's an empty top inventory slot
	for pack = 23, TopInvSlot do
		Write.Debug('top pack: %s', tostring(location.pack))
		if (not mq.TLO.Me.Inventory(pack).ID()) then
			location.pack = pack

			Write.Debug('top pack: %s', tostring(location.pack))
			return location
		end
	end

	-- See if there's an empty bag slot
	for pack = 23, TopInvSlot do
        if (mq.TLO.Me.Inventory(pack).Container() > 0) then
			for slot = 1, mq.TLO.Me.Inventory(pack).Container() do
				if (not mq.TLO.Me.Inventory(pack).Item(slot).ID()) then
					location.pack = pack
					location.slot = slot - 1
		
					Write.Debug('bag pack: %s', tostring(location.pack))
					Write.Debug('bag slot: %s', tostring(location.slot))
					return location
				end
			end
        end
	end

	return nil
end

local function FormatPackLocation(pack, slot)
	local packLocation = ''

	if (slot and slot > -1) then
		packLocation = 'in '
	end

	packLocation = packLocation..'pack'..(pack - 22)

	if (slot and slot > -1) then
		packLocation = packLocation..' '..(slot + 1)
	end

	return packLocation
end

local function SeparateOutSingleItem(itemStack)
	if (UsableInvetoryCount() == 0) then
		return nil
	end

	local location = FindFreeInventory()

	if (not location) then
		return nil
	end

	local pickupCmd = '/ctrlkey /itemnotify '..FormatPackLocation(itemStack.ItemSlot(), itemStack.ItemSlot2())..' leftmouseup'
	local dropCmd = '/itemnotify '..FormatPackLocation(location.pack, location.slot)..' leftmouseup'

	mq.cmd(pickupCmd)

	mq.delay(3000, function ()
		return mq.TLO.Cursor.ID()
	end)

	mq.cmd(dropCmd)

	mq.delay(3000, function ()
		return not mq.TLO.Cursor.ID()
	end)

    local slot = location.slot

    if (slot) then
        slot = slot + 1
    end

	local item = GetItem(location.pack, slot)
	Write.Debug('location: %s', location)
	Write.Debug('new item from pack: %s, slot: %s', item.ItemSlot(), item.ItemSlot2())

	return item
end

local function OpenPack(item)
	Write.Debug('open pack')
	if (item and item.ItemSlot2() ~= nil and item.ItemSlot2() > -1) then
        local pack = GetItem(item.ItemSlot())

        if (pack.Open() == 0) then
            Write.Debug('try to open')
            local openCmd = '/itemnotify '..FormatPackLocation(item.ItemSlot())..' rightmouseup'
    
            mq.cmd(openCmd)

			mq.delay(3000, function ()
				return pack.Open() == 1
			end)
		end
	end
end

local function ClosePack(pack)
	Write.Debug('close pack')
	if (mq.TLO.Me.Inventory(pack).Open() == 1) then
		local closeCmd = '/itemnotify '..FormatPackLocation(pack)..' rightmouseup'

		mq.cmd(closeCmd)

		mq.delay(3000, function ()
			return not mq.TLO.Me.Inventory(pack).Open() == 0
		end)
	end
end

local function CheckPlugin(plugin)
	if (not mq.TLO.Plugin(plugin)) then
        mq.cmdf('/squelch /plugin %s noauto', plugin)
        Write.Debug('\aw%s\ar not detected! \aw This script requires it! Loading ...', plugin)
	end
end

local function OpenBook()

	mq.TLO.Window('SpellBookWnd').DoOpen()
end

local function CloseBook()
	if (mq.TLO.Window('SpellBookWnd').Open()) then
		mq.TLO.Window('SpellBookWnd').DoClose()
	end
end

-- --------------------------------------------------------------------------------------------
-- SUB: ScribeItem
-- --------------------------------------------------------------------------------------------
local function ScribeItem(item)
	local spellName = item.Spell.Name()
	local spellId = item.Spell.ID()
	Write.Info('Scribing %s', spellName)

	OpenPack(item)
	OpenBook()

	mq.delay(200)

	local scribeCmd = '/itemnotify '..FormatPackLocation(item.ItemSlot(), item.ItemSlot2())..' rightmouseup'
	Write.Debug(scribeCmd)

	Scribing = true

	mq.cmd(scribeCmd)

	mq.delay(3000, function ()
        return (mq.TLO.Cursor.ID() or mq.TLO.Window('ConfirmationDialogBox').Open() or IsScribed(spellName, spellId) or not Scribing)
	end)

    Write.Debug('check for open confirmation dialog')
	if (mq.TLO.Window('ConfirmationDialogBox').Open() and 
		mq.TLO.Window('ConfirmationDialogBox').Child('CD_TextOutput').Text():find(mq.TLO.Cursor.Spell.Name()..' will replace')) then
        Write.Debug('click yes to confirm')
        mq.TLO.Window('ConfirmationDialogBox').Child('Yes_Button').LeftMouseUp()
    end

    mq.delay(15000, function ()
        Write.Debug('item is still scribing: %s', Scribing)

        return not Scribing
	end)

	if (mq.TLO.Cursor.ID()) then
        mq.cmd('/autoinv')
        mq.delay(200)
        mq.cmd('/autoinv')
    end
end

local function CheckAndScribe(pack, slot)
	local item = GetItem(pack, slot)

    if (item == nil) then
		Write.Info("Didn't find item in pack: %s, slot: %s", pack, slot)

		return false
	end

	Write.Debug('item.Name(): %s', item.Name())
	-- Write.Debug('item.Type(): %s', item.Type())
	-- Write.Debug("item.Type() ~= 'Scroll': %s", item.Type() ~= 'Scroll')
	-- Write.Debug("item.Type() ~= 'Tome': %s", item.Type() ~= 'Tome')
	-- Write.Debug("(item.Type() ~= 'Scroll' and item.Type() ~= 'Tome'): %s", (item.Type() ~= 'Scroll' and item.Type() ~= 'Tome'))
	-- if ((item.Type() == 'Scroll' or item.Type() == 'Tome')) then
	-- 	Write.Debug('item.Spell.Level(): %d', item.Spell.Level())
	-- 	Write.Debug('MyLevel: %d', MyLevel)
	-- 	Write.Debug('item.Spell.Level() > MyLevel: %s', item.Spell.Level() > MyLevel)
		-- Write.Debug('item.Spell.ID(): %s', item.Spell.ID())
	-- 	Write.Debug('mq.TLO.Me.Book(item.Spell.ID()): %s', mq.TLO.Me.Book(item.Spell.ID())())
	-- 	Write.Debug('mq.TLO.Me.CombatAbility(item.Spell.ID()): %s', mq.TLO.Me.CombatAbility(item.Spell.ID())())
	-- end
	if ((item.Type() ~= 'Scroll' and item.Type() ~= 'Tome') or
		item.Spell.Level() > MyLevel or
		IsScribed(item.Spell.Name(), item.Spell.ID())) then
		Write.Debug('failed basic checks')

		return false
	end

	if (not IsUsableByClass(item)) then
		Write.Debug('not usable by class')

        return false
	end

	if (not IsUsableByDiety(item)) then
		Write.Debug('not usable by diety')

        return false
	end

	local spellName = item.Spell.Name()
	local spellRank = item.Spell.Rank()

	if (spellRank == 2 and
		(IsScribed(spellName..' Rk. III'))) then
		Write.Debug('already have a higher rank spell scribed')

		return false
	elseif (spellRank < 2 and
		(IsScribed(spellName..' Rk. II') or
		IsScribed(spellName..' Rk. III'))) then
		Write.Debug('already have a higher rank spell scribed')

		return false
	end

	if (item.StackCount() > 1) then
		item = SeparateOutSingleItem(item)
		Write.Debug('split item from pack: %s, slot: %s', item.ItemSlot(), item.ItemSlot2())
	end

	if (not item) then
		Write.Debug('no item to scribe')

		return false
	end

	ScribeItem(item)

	return true
end

-- --------------------------------------------------------------------------------------------
-- SUB: ScribeSpells
-- --------------------------------------------------------------------------------------------
local function ScribeSpells()
	if (mq.TLO.Cursor.ID()) then
		mq.cmd('/autoinv')
	end

	--|** Opening your inventory for access bag slots **|
	if (not mq.TLO.Window('InventoryWindow').Open()) then
		mq.TLO.Window('InventoryWindow').DoOpen()
    end

	local scribeCount = 0

	-- Main inventory pack numers are 23-34. 33 & 34 come from add-on perks and may be active for the particular user
	for pack=23, TopInvSlot do
		--|** Check Top Level Inventory Slot to see if it has something in it **|
		if (mq.TLO.Me.Inventory(pack).ID()) then
			--|** Check Top Level Inventory Slot for bag/no bag **|
			if (mq.TLO.Me.Inventory(pack).Container() == 0) then
				--|** If it's not a bag do this **|
				if (CheckAndScribe(pack)) then
					scribeCount = scribeCount + 1
				end
			else
				--|** If it's a bag do this **|
				for slot=1,mq.TLO.Me.Inventory(pack).Container() do
					if (CheckAndScribe(pack, slot - 1)) then
						scribeCount = scribeCount + 1
					end
				end

				ClosePack(pack)
			end
		end
	end

	CloseBook()

	if (scribeCount == 0) then
		DoLoop = false
	end
end

local function EstablishMerchantMode(merchant)
	if (not mq.TLO.Merchant.Open()) then
		if (not merchant and not mq.TLO.Target.ID()) then
			Write.Debug('Not currently in merchant mode')

			return
		end

		if (not mq.TLO.Target.ID()) then
			mq.TLO.Spawn(merchant).DoTarget()

			mq.delay(3000, function ()
				return mq.TLO.Target.Name() == merchant
			end)
		end

		mq.TLO.Merchant.OpenWindow()

		mq.delay(10000, function ()
			return mq.TLO.Merchant.ItemsReceived()
		end)

		if (not mq.TLO.Merchant.Open()) then
			Write.Debug('Could not establish merchant mode')

			return
		end
	end

	return mq.TLO.Target.Name()
end



-- Are we a caster??--
local function CastClass(caster, val)
    for i=1,#caster do
       if caster[i] == val then 
          return true
       end
    end
    return false
end

local caster = {'CLR', 'DRU', 'SHM', 'NEC', 'MAG', 'ENC', 'WIZ'}

-- Walking Zones --
local function SafeZone(safety, val1)
    for _,s in ipairs(safety) do
        if s == val1 then
			Write.Info('We are in a walking Zone')
            return true
        end
    end
	Write.Info('We need a fast way to a walking zone')
    return false
end

local safety = {'poknowledge', 'guildlobby', 'moors', 'crescent'}

local function check_in(value, tbl)
    for _, item in ipairs(tbl) do
        if item == value then
			Write.Info('Returned false')
            return false
        end
    end
	Write.Info('Returned True')
    return true
end

local function WalkZone(walking, val2)
    for _, w in ipairs(walking) do
        if w == val2 then
			Write.Info('We are in a where we want to be')
            return true
        end
    end
	Write.Info('We need to walk to where we are going')
    return false
end

local walking = {'guildlobby', 'moors', 'crescent'}

local ITU = {PAL = '1212', CLR = '1212', SHD = '1212', NEC = '1212', WIZ = '291',
MAG = '291', ENC = '291', BRD = '231'}

local function CastITU()
	for Class, ituc in pairs(ITU) do
		if Class == ClassSN then
			mq.cmdf('/alt act %i', ituc)
		else
			---what can we do for ITU
		end
	end
end

local Invis = {SHD = '531', NEC = '531', WIZ = '1210', MAG = '1210', ENC = '1210',
SHM = '3730', BST = '980', RNG = '80', DRU = '80', BRD = '231', ROG = '1507'}

local function CastInvis()
	for Class, ic in pairs(Invis) do
		local CloudyPot = mq.TLO.FindItem('Cloudy Potion')
		if Class == ClassSN then
			mq.cmdf('/alt act %i', ic)
			mq.delay(5000, function ()
				return mq.TLO.Me.Invis('normal')
			end)
		elseif CloudyPot then
			mq.cmdf('/useitem %s', CloudyPot)
			mq.delay(5000, function ()
				return mq.TLO.Me.Invis('normal')
			end)
		end
	end
end



local function ETWKClass(tbl2, ClassSN)
    for _, lm in ipairs(tbl2) do
        if lm == ClassSN then
			Write.Info('Going Out of safe area area, watch your char for aggro')
			CastInvis()
            return true
        end
    end
    return false
end
local lmovers = {'NEC', 'ROG', 'WIZ', 'SHD'}
local umovers = {'DRU', 'SHA', 'BER', 'BST'}

local function ZoneSN()
	return mq.TLO.Zone.ShortName():lower()
end

-- Let's do Rouneq part of the build --

local function Rouneq()
    local merchant
    
    while (DoLoop) do
        Write.Debug('time: %s', os.clock())
        merchant = EstablishMerchantMode(merchant)
        Write.Debug('time: %s', os.clock())

        if (mq.TLO.Merchant.Open()) then
            Write.Info('Buying all '..MyClass..' spells/tomes for levels '..MinLevel..' to '..MaxLevel)

            BuySpells()

            mq.TLO.Window('MerchantWnd').DoClose()
            
            mq.delay(3000, function ()
                return not mq.TLO.Merchant.Open()
            end)
        end

        ScribeSpells()
    end
end

-- Time to go home --
local function Home()
    if SafeZone(safety, ZoneSN()) == false then
        mq.delay(300)
        if CastClass(caster, ClassSN) then
			::Castagain::
            while (mq.TLO.Me.AltAbilityReady('Gate')) == false do
                Write.Info('Waiting for Gate to be ready, rechecking in 15 seconds')
                mq.delay(15000)
            end
            mq.cmdf('/alt act 1217')
			while mq.TLO.Me.Casting.ID() ~= nil do
				mq.delay(50)
			end
			if SafeZone(safety, ZoneSN()) == false then
				Write.Info('Your spell fizzled or collapsed, preparing to cast again')
				goto Castagain
			end
        else
            local gatePot = mq.TLO.FindItem('Philter of Major Translocation')
            local travelBrew = mq.TLO.FindItem('Ethermere Travel Brew')
            if not gatePot.equal('nil') then 
                Write.Info('Using a gate pot')
                mq.cmdf('/useitem "Philter of Major Translocation"')
            elseif not travelBrew.Equal('nil') then
                Write.Info('Using a travel brew')
                mq.cmdf('/useitem "Ethermere Travel Brew"')
            elseif mq.TLO.Me.AltAbilityReady('Throne of Heroes') == true then
                Write.Info('Trying to cast TOH')
                mq.cmdf('/alt act 511')
                while mq.TLO.Me.Casting.ID() ~= nil do
                    mq.delay(50)
                end
            else
				Write.Info('Using Origin AA to get to your origin home')
				while mq.TLO.Me.AltAbilityReady('Origin') == false do
                    Write.Info('Waiting for Origin to be ready, rechecking in 30 seconds')
                    mq.delay(30000)
                end
                mq.cmdf('/alt act 331')
                while mq.TLO.Me.Casting.ID() ~= nil do
                    mq.delay(100)
				end
            end
        end

		while SafeZone(safety, ZoneSN()) ~= true do
			mq.delay(500)
		end
    end
end

-- Walking distance --
local function TravSafe()
    if WalkZone(walking, ZoneSN()) == true then
        Write.Info('Your close enough, lets walk to POK')
        mq.cmdf('/travelto poknowledge')
        --traveling, please wait--
        while mq.TLO.Navigation.Active() do 
            mq.delay(50)
        end
        mq.delay(50)
        while ZoneSN() ~= 'poknowledge' do
            mq.delay(500)
        end
    end
end

-- Loop Function
local function Vendloop()
    for index, merch in ipairs(Vendlist[ZoneSN()][ClassSN]) do
		if merch == 'nil' then
			goto Skip
		end
		if (ZoneSN() == 'stratos') then
			CastInvis()
			while not mq.TLO.Me.Invis('normal') do
				Write.Info('You\'re stuck in a loop because you\'re not invis')
				mq.delay(5000)
			end
		end
		if (ZoneSN() == 'ethernere' and ETWKClass(lmovers,ClassSN) == true) then
			CastInvis()
			while not mq.TLO.Me.Invis('normal') do
				Write.Info('You\'re stuck in a loop because you\'re not invis')
				mq.delay(5000)
			end
			mq.cmdf('/nav loc -2041.47 -1923.51 -206.41')
			while mq.TLO.Navigation.Active() do
				mq.delay(50)
			end
		end
		if (ZoneSN() == 'ethernere' and ETWKClass(umovers,ClassSN) == true) then
			CastInvis()
			while not mq.TLO.Me.Invis('normal') do
				Write.Info('You\'re stuck in a loop because you\'re not invis')
				mq.delay(5000)
			end
			mq.cmdf('/nav loc -1134.32 -1631.03 -262.38')
			while mq.TLO.Navigation.Active() do
				mq.delay(50)
			end
		end
        Write.Info('naving to target')
        mq.cmdf('/nav spawn npc %s', merch)
            --traveling, please wait --
        while mq.TLO.Navigation.Active() do
            if (mq.TLO.Spawn(merch).Distance3D() < 20) then 
                mq.cmdf('/nav stop') 
            end
            mq.delay(50)
        end
        Write.Info('targeting %s', merch)
        mq.cmdf('/target %s', merch)
        mq.delay(1500)
        Write.Info('Clicking %s', merch)
        mq.cmdf('/click right target')
        while not mq.TLO.Merchant.Open() do
            mq.delay(3000)
        end
        Write.Info('should start rouneq now')
        Rouneq()
        Write.Info('should end rouneq now')
        mq.delay(1500)
        DoLoop = true
        Write.Info('finished loop %i', index)
    end
	::Skip::
end

-- pok buying
local function Trav(area)
	::travrestart::
    if ZoneSN() == area then
		Write.Info('Verifying '..area..' location, please hold')
		if ZoneSN() == 'shardslanding' then
			Write.Info('Naving to a spot to properly function')
			mq.cmdf('/nav loc 337.82 142.24 3.12')
			while mq.TLO.Navigation.Active() do
				mq.delay(50)
			end
		end
		if (ZoneSN() == 'cobaltscartwo') then
			CastInvis()
			while not mq.TLO.Me.Invis('normal') do
				Write.Info('You\'re stuck in a loop because you\'re not invis')
				mq.delay(5000)
			end
		end
        mq.delay(500)
        --time to loop, loop works, but it skips rouneq function. why...--
        Vendloop()
        Write.Info('finished Trav')
	else
		Write.Info('Zone Shortname and area are not the same, please post in forums about the issue')
		while ZoneSN() ~= area do
			mq.delay(50)
		end
		goto travrestart
    end
end

local function guildhall(loc)
	if check_in(ZoneSN(), { loc, "guildhall"}) == true then
		mq.cmdf('/travelto guildhall')
		while ZoneSN() ~= 'guildhall' do
			mq.delay(5000)
		end
	elseif ZoneSN() == loc then
		goto SkippingGH
	end
	::guildhallrestart::
    if ZoneSN() == 'guildhall' then
        mq.cmdf('/nav spawn npc zeflmin werlikanin')
        while mq.TLO.Navigation.Active() do
            mq.delay(50)
        end
        mq.cmdf('/target zeflmin werlikanin')
        mq.cmdf('/click right target')
        while not mq.TLO.Merchant.Open() do
            mq.delay(3000)
        end
        mq.cmdf('/portalsetter %s', loc)
		mq.delay(10000)
        while mq.TLO.PortalSetter.InProgress() do
			mq.delay(50)
		end
        mq.cmdf('/nav loc -22.73 -132.26 3.88')
        while mq.TLO.Navigation.Active() do
            mq.delay(100)
        end
        while not mq.TLO.Window('LargeDialogWindow').Open() do
            mq.delay(500)
        end
        mq.cmdf('/yes')
        while ZoneSN() ~= loc do
            mq.delay(1000)
        end
	else
		Write.Info('We are not in the standard guildhall Please go to standard guild hall')
		while ZoneSN() ~= 'guildhall' do
			mq.delay(50)
		end
		goto guildhallrestart
    end
	::SkippingGH::
end
local function TravWW()
	if (ZoneSN() == 'cobaltscartwo') then
		CastITU()
		while not mq.TLO.Me.Invis('undead') do
			Write.Info('You\'re stuck in a loop because you\'re not itu, please go to western wastes')
			mq.delay(5000)
			if ZoneSN() == 'westwastestwo' then
				goto westwastesstart
			end
		end
		mq.cmdf('/nav loc 980.14 1161.50 53.00')
		while mq.TLO.Navigation.Active() do
			mq.delay(50)
		end
		CastInvis()
		while not mq.TLO.Me.Invis('normal') do
			Write.Info('You\'re stuck in a loop because you\'re not invis')
			mq.delay(5000)
		end
		Write.Info('If you get stuck due to Mesh issues, you\'re headed to western wastes. Scriber will start again when you get there')
		mq.cmdf('/travelto westwastestwo')
		while ZoneSN() ~= 'westwastestwo' do
			mq.delay(50)
		end
	elseif (ZoneSN() == 'westwastestwo') then
		CastITU()
	end
	::westwastesstart::
	Vendloop()
end
-- --------------------------------------------------------------------------------------------
-- SUB: Travel to the venders (Meat which starts the potatoes)
-- --------------------------------------------------------------------------------------------

local function POK()
    if ((MinLevel <= 90) and (MaxLevel >= 1)) == true then
        Home()
        TravSafe()
        Trav('poknowledge')
    end
end
local function Arg()
    if ((MinLevel <= 95) and (MaxLevel >= 91)) == true then
        guildhall('argath')
        Trav('argath')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end
local function Sha()
    if ((MinLevel <= 100) and (MaxLevel >= 96)) == true then
        guildhall('shardslanding')
        Trav('shardslanding')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end
local function ETWK()
    if ((MinLevel <= 100) and (MaxLevel >= 96)) == true then
        guildhall('ethernere')
        Trav('ethernere')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end

local function Kat()
    if ((MinLevel <= 105) and (MaxLevel >= 101)) == true then
        guildhall('kattacastrumb')
        Trav('kattacastrumb')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end

local function POT()
    if ((MinLevel <= 105) and (MaxLevel >= 101)) == true then
        mq.cmdf('/travelto potranquility')
		while ZoneSN() ~= 'potranquility' do
			mq.delay(500)
		end
        Trav('potranquility')

        --Going back to Guild Lobby for next Zone--
        mq.cmdf('/travelto guildlobby')
		while ZoneSN() ~= 'guildlobby' do
			mq.delay(500)
		end
    end
end

local function Lcea()
    if ((MinLevel <= 105) and (MaxLevel >= 101)) == true then
		Write.Info('lceanium shortname is spelled wrong in portalsetter at the moment pending an approval for the fix, please select it yourself')
        guildhall('lceanium')
        Trav('lceanium')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end

local function OT2()
    if ((MinLevel <= 110) and (MaxLevel >= 106)) == true then
        guildhall('overtheretwo')
        Trav('overtheretwo')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end

local function Strat()
    if ((MinLevel <= 110) and (MaxLevel >= 106)) == true then
		mq.cmdf('/travelto stratos')
		while ZoneSN() ~= 'stratos' do
			mq.delay(500)
		end
        Trav('stratos')

        --Going back to Guild Lobby for next Zone--
		mq.cmdf('/travelto guildlobby')
		while ZoneSN() ~= 'guildlobby' do
			mq.delay(500)
		end
    end
end
local function EW2()
    if ((MinLevel <= 115) and (MaxLevel >= 111)) == true then
		Write.Info('eastwastestwo shortname is spelled wrong in portalsetter at the moment pending an approval for the fix, please select it yourself')
        guildhall('eastwastestwo')
        Trav('eastwastestwo')

        --Going back to Guild Lobby for next Zone--
        Home()
    end
end
local function CS2()
    if ((MinLevel <= 115) and (MaxLevel >= 111)) == true then
        guildhall('cobaltscartwo')
        Trav('cobaltscartwo')
    end
end
local function WW2()
    if ((MinLevel <= 115) and (MaxLevel >= 111)) == true then
        TravWW()
		Home()
    end
end
local function ME()
	if ((MinLevel <= 120) and (MaxLevel >= 116)) == true then
		guildhall('maidentwo')
        Trav('maidentwo')
		Home()
    end
end
local function scriber(...)
	local args = {...}
	if (args[1] ~= nil) then
		MinLevel = tonumber(args[1])
	end
	if (args[2] ~= nil) then
		MaxLevel = tonumber(args[2])
	end

	mq.cmdf('/boxr Pause on')

	POK()
    mq.delay(500)
    Arg()
    mq.delay(500)
    Sha()
	mq.delay(500)
	ETWK()
	mq.delay(500)
	Kat()
	mq.delay(500)
	POT()
	mq.delay(500)
	Lcea()
	mq.delay(500)
	OT2()
	mq.delay(500)
	Strat()
	mq.delay(500)
	EW2()
	mq.delay(500)
	CS2()
	mq.delay(500)
	WW2()
	mq.delay(500)
	ME()
	mq.cmdf('/boxr pause off')
end
local function setup()
	mq.bind('/scriber', scriber)
	mq.bind('/sc', scriber)
	Write.Info('Welcome to Scriber, you can use the function /scriber, or /sc followed by the minimum level and maximum level you want start looking for spells to scribe')
	Write.Info('i.e. /scriber 91 95 or /sc 1 120')
end
local function StayinAlive()
	while true do
		mq.delay(2500)
	end
end
CheckPlugin('MQ2PortalSetter')
CheckPlugin('MQ2Nav')
CheckPlugin('MQ2Boxr')

setup()
StayinAlive()